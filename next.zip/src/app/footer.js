import React from 'react'
import './globals.css'

export default function footer() {
  return (
    <div className='footer-wave'>
    <div className="ocean">
  <div className="wave"></div>
  <div className="wave"></div>
</div>
    </div>
  )
}
